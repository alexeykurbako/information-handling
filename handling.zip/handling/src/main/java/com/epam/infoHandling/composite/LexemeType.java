package com.epam.infoHandling.composite;

public enum LexemeType {
    WORD, EXPRESSION
}
